// import logo from './logo.svg';
import React from 'react';
import GetGroupInfo from '../component/GetGroupInfo.js';
import UpdateGroup from '../component/UpdateGroup.js';
import GetUserInfo from '../component/GetUserInfo.js';


function myPage() {
  return (
    <div>
      mypage
    </div>
  );
}

export default myPage;
